Hazelwood Furniture - Final Website bundle

Files in this folder:
- index.html    -> Main editable website file. Open in any text editor to edit content.
- logo.jpg      -> Logo image (replace with your logo, keep name 'logo.jpg')

Contact info used in this build:
- Phone: +91 8077091922
- Email: hazelwood0006@gmail.com
- Address: Kirti Nagar, New Delhi, India
- Website: hazelwoodfurniture.sale

Quick edit instructions:
1) Open index.html in a text editor (Notepad, VSCode) and edit any text directly.
2) Replace logo.jpg with your actual logo file (same name) if you want higher-res.
3) To change the showroom photo, add a file named showroom.jpg in same folder and replace the placeholder.
4) Upload this folder to your hosting provider (public_html) or use GitHub Pages to publish.

If you want, I can provide step-by-step instructions to upload to GoDaddy or Hostinger.